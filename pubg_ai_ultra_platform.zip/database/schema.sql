
CREATE TABLE players(
id SERIAL PRIMARY KEY,
nickname TEXT,
kd FLOAT,
adr INT,
winrate FLOAT,
matches INT
);

CREATE TABLE matches(
id SERIAL PRIMARY KEY,
kills INT,
placement INT,
damage INT
);
