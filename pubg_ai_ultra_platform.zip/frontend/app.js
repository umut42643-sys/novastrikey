
const API="http://localhost:3000"

async function profile(){
 const r=await fetch(API+"/profile")
 const d=await r.json()
 document.getElementById("app").innerHTML=`
 <div class="card">
 <h2>${d.nickname}</h2>
 KD:${d.kd}<br>
 ADR:${d.adr}<br>
 Winrate:${d.winrate}
 </div>`
}

async function maps(){
 const r=await fetch(API+"/maps")
 const data=await r.json()
 let html=""
 data.forEach(m=>{
 html+=`<div class="card">${m.map} - ${m.winrate}</div>`
 })
 document.getElementById("app").innerHTML=html
}

async function matches(){
 const r=await fetch(API+"/matches")
 const data=await r.json()
 let html=""
 data.forEach(m=>{
 html+=`<div class="card">Kills:${m.kills} Placement:${m.placement}</div>`
 })
 document.getElementById("app").innerHTML=html
}

async function ranking(){
 const r=await fetch(API+"/ranking")
 const data=await r.json()
 let html=""
 data.forEach(p=>{
 html+=`<div class="card">${p.player} ${p.points}</div>`
 })
 document.getElementById("app").innerHTML=html
}

async function news(){
 const r=await fetch(API+"/news")
 const data=await r.json()
 let html=""
 data.forEach(n=>{
 html+=`<div class="card">${n.title}</div>`
 })
 document.getElementById("app").innerHTML=html
}
