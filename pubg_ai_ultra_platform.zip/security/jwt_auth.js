
const jwt=require('jsonwebtoken')

function createToken(user){
 return jwt.sign(user,"ultra_secure_pubg_key",{expiresIn:"24h"})
}

module.exports={createToken}
