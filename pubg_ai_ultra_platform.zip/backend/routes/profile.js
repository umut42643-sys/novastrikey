
const router = require('express').Router()

router.get('/', (req,res)=>{

res.json({
nickname:"UltraPUBGPro",
kd:2.31,
adr:450,
winrate:"21%",
top10:"58%",
matches:720,
headshot:"32%"
})

})

module.exports = router
