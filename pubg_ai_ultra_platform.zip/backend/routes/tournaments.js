
const router = require('express').Router()

router.get('/', (req,res)=>{

res.json([
{name:"PUBG Global Championship",date:"2026-11"},
{name:"PUBG Nations Cup",date:"2026-07"},
{name:"PUBG Pro League",date:"2026-05"}
])

})

module.exports = router
