
const router = require('express').Router()

router.get('/', (req,res)=>{

res.json([
{map:"Erangel",winrate:"24%"},
{map:"Miramar",winrate:"20%"},
{map:"Sanhok",winrate:"22%"},
{map:"Vikendi",winrate:"19%"},
{map:"Deston",winrate:"23%"}
])

})

module.exports = router
