
const router = require('express').Router()

router.get('/',(req,res)=>{

res.json([
{kills:8,placement:3,damage:620},
{kills:4,placement:7,damage:350},
{kills:10,placement:1,damage:840}
])

})

module.exports = router
