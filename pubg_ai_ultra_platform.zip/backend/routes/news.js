
const router = require('express').Router()

router.get('/',(req,res)=>{

res.json([
{title:"PUBG weapon balance update"},
{title:"New esports roster announced"},
{title:"Upcoming global tournament revealed"}
])

})

module.exports = router
