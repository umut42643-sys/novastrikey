
const router = require('express').Router()

router.get('/',(req,res)=>{

res.json([
{player:"PlayerA",points:5400},
{player:"PlayerB",points:5200},
{player:"PlayerC",points:5000}
])

})

module.exports = router
