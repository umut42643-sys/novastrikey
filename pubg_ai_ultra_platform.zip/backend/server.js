
const express = require('express')
const cors = require('cors')

const profile = require('./routes/profile')
const maps = require('./routes/maps')
const tournaments = require('./routes/tournaments')
const news = require('./routes/news')
const matches = require('./routes/matches')
const ranking = require('./routes/ranking')

const app = express()

app.use(cors())
app.use(express.json())

app.use('/profile', profile)
app.use('/maps', maps)
app.use('/tournaments', tournaments)
app.use('/news', news)
app.use('/matches', matches)
app.use('/ranking', ranking)

app.listen(3000, () => {
console.log("PUBG AI Ultra Platform running on 3000")
})
